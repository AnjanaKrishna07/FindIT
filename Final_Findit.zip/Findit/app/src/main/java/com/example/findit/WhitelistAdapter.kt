package com.example.findit

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton

class WhitelistAdapter(private val onRemoveClick: (String) -> Unit) :
    RecyclerView.Adapter<WhitelistAdapter.WhitelistViewHolder>() {

    private var whitelist: List<String> = emptyList()

    fun updateWhitelist(newWhitelist: List<String>) {
        whitelist = newWhitelist
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WhitelistViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_whitelist, parent, false)
        return WhitelistViewHolder(view)
    }

    override fun onBindViewHolder(holder: WhitelistViewHolder, position: Int) {
        holder.bind(whitelist[position])
    }

    override fun getItemCount(): Int = whitelist.size

    inner class WhitelistViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val numberTextView: TextView = itemView.findViewById(R.id.numberTextView)
        private val removeButton: MaterialButton = itemView.findViewById(R.id.removeButton)

        fun bind(number: String) {
            numberTextView.text = number
            removeButton.setOnClickListener {
                onRemoveClick(number)
            }
        }
    }
} 