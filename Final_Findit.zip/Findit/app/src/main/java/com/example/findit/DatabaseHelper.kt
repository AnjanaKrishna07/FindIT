package com.example.findit

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log

data class User(
    val id: String,
    val name: String,
    val email: String?,
    val phone: String?,
    val password: String
)

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "FindIt.db"
        private const val DATABASE_VERSION = 1
        private const val TABLE_USERS = "users"
        private const val COLUMN_ID = "id"
        private const val COLUMN_NAME = "name"
        private const val COLUMN_EMAIL = "email"
        private const val COLUMN_PHONE = "phone"
        private const val COLUMN_PASSWORD = "password"
    }

    override fun onCreate(db: SQLiteDatabase) {
        try {
            val createTable = """
                CREATE TABLE $TABLE_USERS (
                    $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                    $COLUMN_NAME TEXT NOT NULL,
                    $COLUMN_EMAIL TEXT,
                    $COLUMN_PHONE TEXT,
                    $COLUMN_PASSWORD TEXT NOT NULL
                )
            """.trimIndent()
            db.execSQL(createTable)
            
            // Insert test user
            insertTestUser(db)
        } catch (e: Exception) {
            Log.e("DatabaseHelper", "Error creating database", e)
        }
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
        onCreate(db)
    }

    private fun insertTestUser(db: SQLiteDatabase) {
        try {
            val values = ContentValues().apply {
                put(COLUMN_NAME, "Test User")
                put(COLUMN_EMAIL, "test@example.com")
                put(COLUMN_PHONE, "1234567890")
                put(COLUMN_PASSWORD, "password123")
            }
            db.insert(TABLE_USERS, null, values)
            Log.d("DatabaseHelper", "Test user inserted successfully")
        } catch (e: Exception) {
            Log.e("DatabaseHelper", "Error inserting test user", e)
        }
    }

    fun ensureTestUser() {
        val db = this.writableDatabase
        val cursor = db.query(TABLE_USERS, null, null, null, null, null, null)
        
        if (cursor.count == 0) {
            insertTestUser(db)
        }
        cursor.close()
    }

    fun addUser(name: String, email: String?, phone: String?, password: String): Boolean {
        try {
            val db = this.writableDatabase
            val values = ContentValues().apply {
                put(COLUMN_NAME, name)
                put(COLUMN_EMAIL, email)
                put(COLUMN_PHONE, phone)
                put(COLUMN_PASSWORD, password)
            }
            return db.insert(TABLE_USERS, null, values) != -1L
        } catch (e: Exception) {
            Log.e("DatabaseHelper", "Error adding user", e)
            return false
        }
    }

    fun checkUser(emailOrPhone: String, password: String): User? {
        try {
            val db = this.readableDatabase
            
            // First try exact match
            var selection = "($COLUMN_EMAIL = ? OR $COLUMN_PHONE = ?) AND $COLUMN_PASSWORD = ?"
            var selectionArgs = arrayOf(emailOrPhone, emailOrPhone, password)
            
            var cursor = db.query(
                TABLE_USERS,
                null,
                selection,
                selectionArgs,
                null,
                null,
                null
            )
            
            // If no exact match found and input contains @, try case-insensitive email match
            if (!cursor.moveToFirst() && emailOrPhone.contains("@")) {
                cursor.close()
                selection = "LOWER($COLUMN_EMAIL) = LOWER(?) AND $COLUMN_PASSWORD = ?"
                selectionArgs = arrayOf(emailOrPhone, password)
                
                cursor = db.query(
                    TABLE_USERS,
                    null,
                    selection,
                    selectionArgs,
                    null,
                    null,
                    null
                )
            }
            
            return if (cursor.moveToFirst()) {
                val user = User(
                    id = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ID)),
                    name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME)),
                    email = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EMAIL)),
                    phone = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PHONE)),
                    password = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PASSWORD))
                )
                cursor.close()
                Log.d("DatabaseHelper", "User found: ${user.email ?: user.phone}")
                user
            } else {
                cursor.close()
                Log.d("DatabaseHelper", "No user found for: $emailOrPhone")
                null
            }
        } catch (e: Exception) {
            Log.e("DatabaseHelper", "Error checking user", e)
            return null
        }
    }

    fun isEmailOrPhoneExists(emailOrPhone: String): Boolean {
        try {
            val db = this.readableDatabase
            val selection = "LOWER($COLUMN_EMAIL) = LOWER(?) OR $COLUMN_PHONE = ?"
            val selectionArgs = arrayOf(emailOrPhone, emailOrPhone)
            
            val cursor = db.query(
                TABLE_USERS,
                null,
                selection,
                selectionArgs,
                null,
                null,
                null
            )
            
            val exists = cursor.count > 0
            cursor.close()
            return exists
        } catch (e: Exception) {
            Log.e("DatabaseHelper", "Error checking email/phone existence", e)
            return false
        }
    }
} 