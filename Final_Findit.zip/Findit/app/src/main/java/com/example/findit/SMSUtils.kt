package com.example.findit

import android.content.Context
import android.telephony.SmsManager
import android.widget.Toast

object SMSUtils {
    private const val COMMAND_PREFIX = "FINDIT"

    fun sendCommand(context: Context, phoneNumber: String, command: String, passcode: String) {
        try {
            val message = "$COMMAND_PREFIX$passcode $command"
            SmsManager.getDefault().sendTextMessage(phoneNumber, null, message, null, null)
            Toast.makeText(context, "Command sent successfully", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(context, "Failed to send command: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun sendLocation(context: Context, phoneNumber: String, passcode: String, latitude: Double, longitude: Double) {
        try {
            val message = "$COMMAND_PREFIX$passcode LOCATION $latitude,$longitude"
            SmsManager.getDefault().sendTextMessage(phoneNumber, null, message, null, null)
            Toast.makeText(context, "Location sent successfully", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(context, "Failed to send location: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun sendContact(context: Context, phoneNumber: String, passcode: String, contactName: String, contactNumber: String) {
        try {
            val message = "$COMMAND_PREFIX$passcode CONTACT $contactName:$contactNumber"
            SmsManager.getDefault().sendTextMessage(phoneNumber, null, message, null, null)
            Toast.makeText(context, "Contact sent successfully", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(context, "Failed to send contact: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun sendStatus(context: Context, phoneNumber: String, passcode: String, batteryLevel: Int, ringerMode: String) {
        try {
            val message = "$COMMAND_PREFIX$passcode STATUS $batteryLevel,$ringerMode"
            SmsManager.getDefault().sendTextMessage(phoneNumber, null, message, null, null)
            Toast.makeText(context, "Status sent successfully", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(context, "Failed to send status: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
} 