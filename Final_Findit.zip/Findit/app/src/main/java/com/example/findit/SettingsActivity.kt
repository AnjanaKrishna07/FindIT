package com.example.findit

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.findit.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Settings"

        // Set up click listeners
        binding.notificationSwitch.setOnCheckedChangeListener { _, isChecked ->
            // Save notification preference
            getSharedPreferences("settings", MODE_PRIVATE).edit()
                .putBoolean("notifications_enabled", isChecked)
                .apply()
            Toast.makeText(this, 
                "Notifications ${if (isChecked) "enabled" else "disabled"}", 
                Toast.LENGTH_SHORT).show()
        }

        binding.securitySwitch.setOnCheckedChangeListener { _, isChecked ->
            // Save security preference
            getSharedPreferences("settings", MODE_PRIVATE).edit()
                .putBoolean("security_enabled", isChecked)
                .apply()
            Toast.makeText(this, 
                "Security features ${if (isChecked) "enabled" else "disabled"}", 
                Toast.LENGTH_SHORT).show()
        }

        // Load saved preferences
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        binding.notificationSwitch.isChecked = prefs.getBoolean("notifications_enabled", true)
        binding.securitySwitch.isChecked = prefs.getBoolean("security_enabled", true)

        binding.toolbar.setNavigationOnClickListener {
            finish()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
} 