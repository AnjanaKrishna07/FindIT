package com.example.findit

import android.app.Dialog
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment

class InstructionDialog : DialogFragment() {

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val title = arguments?.getString(ARG_TITLE) ?: ""
        val instruction = arguments?.getString(ARG_INSTRUCTION) ?: ""

        return AlertDialog.Builder(requireContext())
            .setTitle(title)
            .setMessage(instruction)
            .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
            .create()
    }

    companion object {
        private const val ARG_TITLE = "title"
        private const val ARG_INSTRUCTION = "instruction"

        fun newInstance(title: String, instruction: String): InstructionDialog {
            val fragment = InstructionDialog()
            fragment.arguments = Bundle().apply {
                putString(ARG_TITLE, title)
                putString(ARG_INSTRUCTION, instruction)
            }
            return fragment
        }
    }
} 