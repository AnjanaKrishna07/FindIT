package com.example.findit

import android.content.*
import android.media.AudioManager
import android.os.BatteryManager
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import com.example.findit.databinding.ActivityDashboardBinding
import com.google.android.material.snackbar.Snackbar

class DashboardActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDashboardBinding

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            binding.batteryStatusTextView.text = "Battery: $level%"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // 🛠 Button Clicks
        binding.ringPhoneButton.setOnClickListener {
            Snackbar.make(it, "Ring phone feature coming soon", Snackbar.LENGTH_SHORT).show()
        }

        binding.getLocationButton.setOnClickListener {
            Snackbar.make(it, "Get location feature coming soon", Snackbar.LENGTH_SHORT).show()
        }

        binding.getContactButton.setOnClickListener {
            Snackbar.make(it, "Get contact feature coming soon", Snackbar.LENGTH_SHORT).show()
        }

        binding.lockUnlockButton.setOnClickListener {
            Snackbar.make(it, "Lock/unlock feature coming soon", Snackbar.LENGTH_SHORT).show()
        }

        binding.emergencyButton.setOnClickListener {
            Snackbar.make(it, "Emergency feature coming soon", Snackbar.LENGTH_SHORT).show()
        }

        binding.settingsButton.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        updateRingerStatus()
    }

    override fun onResume() {
        super.onResume()
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(batteryReceiver)
    }

    private fun updateRingerStatus() {
        val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val ringerMode = when (audioManager.ringerMode) {
            AudioManager.RINGER_MODE_SILENT -> "Silent"
            AudioManager.RINGER_MODE_VIBRATE -> "Vibrate"
            AudioManager.RINGER_MODE_NORMAL -> "Normal"
            else -> "Unknown"
        }
        binding.ringerStatusTextView.text = "Ringer: $ringerMode"
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_dashboard, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> {
                startActivity(Intent(this, SettingsActivity::class.java))
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
