package com.example.findit

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.findit.databinding.ActivityBlockedContactsBinding

class BlockedContactsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityBlockedContactsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBlockedContactsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Blocked Contacts"

        binding.toolbar.setNavigationOnClickListener {
            finish()
        }

        binding.fabAddContact.setOnClickListener {
            // TODO: Implement add contact functionality
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    companion object {
        fun newIntent(context: Context): Intent {
            return Intent(context, BlockedContactsActivity::class.java)
        }
    }
} 