package com.example.findit

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.telephony.SmsMessage
import android.util.Log
import android.widget.Toast

class SMSReceiver : BroadcastReceiver() {
    companion object {
        private const val COMMAND_PREFIX = "FINDIT"
        private const val COMMAND_RING = "RING"
        private const val COMMAND_LOCATION = "LOCATION"
        private const val COMMAND_CONTACT = "CONTACT"
        private const val COMMAND_STATUS = "STATUS"
        private const val COMMAND_LOCK = "LOCK"
        private const val COMMAND_UNLOCK = "UNLOCK"
        private const val COMMAND_EMERGENCY = "EMERGENCY"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Telephony.Sms.Intents.SMS_RECEIVED_ACTION) {
            val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
            for (message in messages) {
                val messageBody = message.messageBody
                val sender = message.originatingAddress

                Log.d("SMSReceiver", "Received SMS from: $sender | Body: $messageBody")

                if (messageBody.uppercase().startsWith(COMMAND_PREFIX)) {
                    val parts = messageBody.split(" ")
                    if (parts.size >= 3) {  // FINDIT passcode command
                        val passcode = parts[1]
                        val command = parts[2].uppercase()

                        Log.d("SMSReceiver", "Parsed passcode: $passcode | Command: $command")

                        if (SecurityUtils.isValidPasscode(context, passcode) &&
                            SecurityUtils.isAuthorizedNumber(context, sender ?: "")) {
                            Log.d("SMSReceiver", "Authorization successful for sender: $sender")
                            handleCommand(context, command, parts.drop(3), sender)
                        } else {
                            Log.d("SMSReceiver", "Authorization FAILED for sender: $sender with passcode: $passcode")
                            Toast.makeText(context, "Invalid passcode or unauthorized sender", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        Log.d("SMSReceiver", "Malformed message: insufficient parts")
                    }
                } else {
                    Log.d("SMSReceiver", "SMS does not start with FINDIT prefix, ignored")
                }
            }
        }
    }

    private fun handleCommand(context: Context, command: String, args: List<String>, sender: String?) {
        when (command) {
            COMMAND_RING -> {
                DeviceUtils.ringPhone(context)
                SMSUtils.sendStatus(context, sender ?: "", SecurityUtils.getPasscode(context) ?: "",
                    DeviceUtils.getBatteryLevel(context), DeviceUtils.getRingerMode(context))
            }
            COMMAND_LOCATION -> {
                LocationUtils.getCurrentLocation(context) { location ->
                    if (location != null) {
                        SMSUtils.sendLocation(context, sender ?: "", SecurityUtils.getPasscode(context) ?: "",
                            location.latitude, location.longitude)
                    } else {
                        Toast.makeText(context, "Failed to get location", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            COMMAND_CONTACT -> {
                if (args.isNotEmpty()) {
                    val contactName = args[0]
                    val contactNumber = ContactUtils.getContactNumber(context, contactName)
                    if (contactNumber != null) {
                        SMSUtils.sendContact(context, sender ?: "", SecurityUtils.getPasscode(context) ?: "",
                            contactName, contactNumber)
                    } else {
                        Toast.makeText(context, "Contact not found", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            COMMAND_STATUS -> {
                SMSUtils.sendStatus(context, sender ?: "", SecurityUtils.getPasscode(context) ?: "",
                    DeviceUtils.getBatteryLevel(context), DeviceUtils.getRingerMode(context))
            }
            COMMAND_LOCK -> {
                DeviceUtils.lockPhone(context)
                SMSUtils.sendCustomMessage(
                    context,
                    sender ?: "",
                    SecurityUtils.getPasscode(context) ?: "",
                    "LOCKED"
                )
            }

            COMMAND_UNLOCK -> {
                DeviceUtils.unlockPhone(context)
                SMSUtils.sendStatus(context, sender ?: "", SecurityUtils.getPasscode(context) ?: "",
                    DeviceUtils.getBatteryLevel(context), DeviceUtils.getRingerMode(context))
            }
            COMMAND_EMERGENCY -> {
                val whitelist = SecurityUtils.getWhitelist(context)
                val passcode = SecurityUtils.getPasscode(context) ?: ""
                LocationUtils.getCurrentLocation(context) { location ->
                    if (location != null) {
                        whitelist.forEach { number ->
                            SMSUtils.sendLocation(context, number, passcode, location.latitude, location.longitude)
                        }
                    }
                }
                whitelist.forEach { number ->
                    SMSUtils.sendStatus(context, number, passcode,
                        DeviceUtils.getBatteryLevel(context), DeviceUtils.getRingerMode(context))
                }
            }
            else -> {
                Log.d("SMSReceiver", "Unknown command: $command")
            }
        }
    }
}
