package com.example.findit

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

class SignUpActivity : AppCompatActivity() {
    private lateinit var nameEditText: TextInputEditText
    private lateinit var emailPhoneEditText: TextInputEditText
    private lateinit var passwordEditText: TextInputEditText
    private lateinit var confirmPasswordEditText: TextInputEditText
    private lateinit var nameInputLayout: TextInputLayout
    private lateinit var emailPhoneInputLayout: TextInputLayout
    private lateinit var passwordInputLayout: TextInputLayout
    private lateinit var confirmPasswordInputLayout: TextInputLayout
    private lateinit var databaseHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        databaseHelper = DatabaseHelper(this)

        // Initialize views
        nameEditText = findViewById(R.id.nameEditText)
        emailPhoneEditText = findViewById(R.id.emailPhoneEditText)
        passwordEditText = findViewById(R.id.passwordEditText)
        confirmPasswordEditText = findViewById(R.id.confirmPasswordEditText)
        nameInputLayout = findViewById(R.id.nameInputLayout)
        emailPhoneInputLayout = findViewById(R.id.emailPhoneInputLayout)
        passwordInputLayout = findViewById(R.id.passwordInputLayout)
        confirmPasswordInputLayout = findViewById(R.id.confirmPasswordInputLayout)

        // Set up click listeners
        findViewById<com.google.android.material.button.MaterialButton>(R.id.signUpButton).setOnClickListener {
            attemptSignUp()
        }

        findViewById<android.widget.TextView>(R.id.loginTextView).setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }

    private fun attemptSignUp() {
        val name = nameEditText.text.toString().trim()
        val emailPhone = emailPhoneEditText.text.toString().trim()
        val password = passwordEditText.text.toString().trim()
        val confirmPassword = confirmPasswordEditText.text.toString().trim()

        // Reset errors
        nameInputLayout.error = null
        emailPhoneInputLayout.error = null
        passwordInputLayout.error = null
        confirmPasswordInputLayout.error = null

        // Validate inputs
        if (name.isEmpty()) {
            nameInputLayout.error = "Name is required"
            return
        }

        if (emailPhone.isEmpty()) {
            emailPhoneInputLayout.error = "Email or phone is required"
            return
        }

        // Validate email/phone format
        if (emailPhone.contains("@")) {
            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(emailPhone).matches()) {
                emailPhoneInputLayout.error = "Invalid email format"
                return
            }
        } else if (emailPhone.all { it.isDigit() }) {
            if (emailPhone.length < 9 || emailPhone.length > 15) {
                emailPhoneInputLayout.error = "Please enter a valid phone number"
                return
            }
        } else {
            emailPhoneInputLayout.error = "Enter a valid email or phone number"
            return
        }

        if (password.isEmpty()) {
            passwordInputLayout.error = "Password is required"
            return
        }

        if (confirmPassword.isEmpty()) {
            confirmPasswordInputLayout.error = "Please confirm your password"
            return
        }

        if (password != confirmPassword) {
            confirmPasswordInputLayout.error = "Passwords do not match"
            return
        }

        if (password.length < 6) {
            passwordInputLayout.error = "Password must be at least 6 characters"
            return
        }

        // Check if email/phone already exists
        if (databaseHelper.isEmailOrPhoneExists(emailPhone)) {
            emailPhoneInputLayout.error = "Email or phone already registered"
            return
        }

        // Add user to database
        val isEmail = emailPhone.contains("@")
        val success = if (isEmail) {
            databaseHelper.addUser(name, emailPhone, null, password)
        } else {
            databaseHelper.addUser(name, null, emailPhone, password)
        }

        if (success) {
            Toast.makeText(this, "Registration successful", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        } else {
            Toast.makeText(this, "Registration failed", Toast.LENGTH_SHORT).show()
        }
    }
} 