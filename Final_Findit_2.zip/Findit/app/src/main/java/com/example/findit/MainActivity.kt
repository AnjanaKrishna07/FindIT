package com.example.findit

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.addCallback
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.GravityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import com.example.findit.databinding.ActivityMainBinding
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {
    private lateinit var binding: ActivityMainBinding
    private lateinit var sessionManager: SessionManager
    private lateinit var toggle: ActionBarDrawerToggle
    private val PERMISSIONS_REQUEST_CODE = 123
    private var backPressedTime: Long = 0
    private val BACK_PRESS_INTERVAL = 2000 // 2 seconds

    companion object {
        private const val TAG = "MainActivity"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            sessionManager = SessionManager(this)
            if (!sessionManager.isLoggedIn()) {
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
                return
            }

            binding = ActivityMainBinding.inflate(layoutInflater)
            setContentView(binding.root)

            setupWindowInsets()
            setupToolbar()
            setupNavigationDrawer()
            setupCards()
            checkAndRequestPermissions()
        } catch (e: Exception) {
            Log.e("MainActivity", "Error in onCreate", e)
            Toast.makeText(this, "Error initializing app: ${e.message}", Toast.LENGTH_LONG).show()
            handleFatalError(e)
        }
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setHomeButtonEnabled(true)
    }

    private fun setupNavigationDrawer() {
        toggle = ActionBarDrawerToggle(
            this,
            binding.drawerLayout,
            binding.toolbar,
            R.string.navigation_drawer_open,
            R.string.navigation_drawer_close
        )
        binding.drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        binding.navigationView.setNavigationItemSelectedListener(this)
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.nav_home -> {
                // Already on home, just close drawer
                binding.drawerLayout.closeDrawer(GravityCompat.START)
            }
            R.id.nav_history -> {
                // TODO: Implement history screen
                Toast.makeText(this, "History - Coming soon", Toast.LENGTH_SHORT).show()
            }
            R.id.nav_settings -> {
                startActivity(Intent(this, SettingsActivity::class.java))
            }
            R.id.nav_permissions -> {
                checkAndRequestPermissions()
            }
            R.id.nav_share -> {
                shareApp()
            }
            R.id.nav_logout -> {
                logout()
            }
            R.id.nav_uninstall -> {
                uninstallApp()
            }
        }
        binding.drawerLayout.closeDrawer(GravityCompat.START)
        return true
    }

    private fun shareApp() {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "FindIt App")
            putExtra(Intent.EXTRA_TEXT, "Check out FindIt App - helps you find your phone remotely!")
        }
        startActivity(Intent.createChooser(intent, "Share via"))
    }

    private fun logout() {
        sessionManager.clearSession()
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }

    private fun uninstallApp() {
        val intent = Intent(Intent.ACTION_DELETE).apply {
            data = Uri.parse("package:${packageName}")
        }
        startActivity(intent)
    }

    override fun onBackPressed() {
        if (binding.drawerLayout.isDrawerOpen(GravityCompat.START)) {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }

    private fun setupWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { view, windowInsets ->
            val insets = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.updatePadding(top = insets.top)
            WindowInsetsCompat.CONSUMED
        }
    }

    private fun setupCards() {
        try {
            binding.contactsCard.setOnClickListener {
                showInstructionDialog("Access Contacts", 
                    "Send SMS: findit <password> getcontact <contact_name>\nExample: findit password123 getcontact john")
            }

            binding.locationCard.setOnClickListener {
                showInstructionDialog("Access Location",
                    "Send SMS: findit <password> getlocation")
            }

            binding.soundCard.setOnClickListener {
                showInstructionDialog("Change Sound Profile",
                    "Send SMS: findit <password> sound <mode>\nModes: silent, vibrate, normal\nExample: findit password123 sound silent")
            }

            binding.alarmCard.setOnClickListener {
                showInstructionDialog("Alarm Mobile",
                    "Send SMS: findit <password> alarm <duration_seconds>\nExample: findit password123 alarm 30")
            }

            binding.lockCard.setOnClickListener {
                showInstructionDialog("Lock Mobile Screen",
                    "Send SMS: findit <password> lock")
            }

            binding.emergencyCard.setOnClickListener {
                showInstructionDialog("Emergency Mode", 
                    "Send SMS: findit <password> emergency\n\n" +
                    "This will:\n" +
                    "1. Trigger maximum volume alarm\n" +
                    "2. Flash camera light\n" +
                    "3. Send precise location\n" +
                    "4. Record 10s audio clip\n" +
                    "5. Take photos from both cameras\n" +
                    "6. Send all data back via SMS\n\n" +
                    "Example: findit password123 emergency")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error setting up card listeners", e)
        }
    }

    private fun showInstructionDialog(title: String, instruction: String) {
        try {
            val dialog = InstructionDialog.newInstance(title, instruction)
            dialog.show(supportFragmentManager, "instruction_dialog")
        } catch (e: Exception) {
            Log.e(TAG, "Error showing instruction dialog", e)
            Toast.makeText(this, "Unable to show instructions", Toast.LENGTH_SHORT).show()
        }
    }

    private fun handleFatalError(e: Exception) {
        Log.e(TAG, "Fatal error occurred", e)
        Toast.makeText(this, "Error initializing app. Please try again.", Toast.LENGTH_LONG).show()
        sessionManager.clearSession()
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }

    private fun checkAndRequestPermissions() {
        val permissions = arrayOf(
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_PHONE_STATE
        )

        val permissionsToRequest = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (permissionsToRequest.isNotEmpty()) {
            ActivityCompat.requestPermissions(
                this,
                permissionsToRequest.toTypedArray(),
                PERMISSIONS_REQUEST_CODE
            )
        } else {
            Toast.makeText(this, "All required permissions are already granted", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSIONS_REQUEST_CODE) {
            val deniedPermissions = permissions.filterIndexed { index, _ ->
                grantResults[index] != PackageManager.PERMISSION_GRANTED
            }
            
            if (deniedPermissions.isEmpty()) {
                Toast.makeText(this, "All permissions granted", Toast.LENGTH_SHORT).show()
            } else {
                val message = buildString {
                    append("The following permissions were denied:\n")
                    deniedPermissions.forEach { permission ->
                        append("- ${permission.split(".").last()}\n")
                    }
                    append("\nSome features may not work properly.")
                }
                Toast.makeText(this, message, Toast.LENGTH_LONG).show()
            }
        }
    }
} 