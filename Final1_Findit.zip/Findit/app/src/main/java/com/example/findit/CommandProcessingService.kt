package com.example.findit

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.telephony.SmsManager
import android.util.Log
import androidx.core.app.NotificationCompat

class CommandProcessingService : Service() {
    companion object {
        private const val TAG = "CommandProcessingService"
        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "find_it_command_channel"
    }

    private var wakeLock: PowerManager.WakeLock? = null
    private var wakeLockId: String? = null

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onDestroy() {
        super.onDestroy()
        releaseWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d(TAG, "Service started")
        
        // Create and display a notification to keep the service in foreground
        val notification = createNotification("Processing command...")
        startForeground(NOTIFICATION_ID, notification)
        
        // Get the wake lock ID if passed from the broadcast receiver
        wakeLockId = intent?.getStringExtra("wakeLockId")
        
        // Create our own wake lock if needed
        if (wakeLock == null) {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = powerManager.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "com.example.findit:SERVICE_WAKE_LOCK"
            )
            wakeLock?.acquire(5 * 60 * 1000) // 5 minutes max
            Log.d(TAG, "Service wake lock acquired")
        }
        
        // Process the command in a separate thread
        Thread {
            try {
                intent?.let { 
                    val command = it.getStringExtra("command") ?: ""
                    val sender = it.getStringExtra("sender") ?: ""
                    val args = it.getStringArrayListExtra("args") ?: arrayListOf()
                    
                    Log.d(TAG, "Processing command: $command from $sender with args: $args")
                    
                    when (command) {
                        "getlocation" -> handleLocationCommand(sender, args)
                        "getcontact" -> handleContactCommand(sender, args)
                        "alarm" -> handleAlarmCommand(sender, args)
                        // Add other long-running commands here
                        else -> {
                            Log.w(TAG, "Unknown command for service: $command")
                            sendResponse(sender, "Unknown command")
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error processing command", e)
            } finally {
                stopSelf()
            }
        }.start()
        
        return START_NOT_STICKY
    }

    private fun handleLocationCommand(sender: String, args: List<String>) {
        Log.d(TAG, "Handling getlocation command in service")
        var locationSent = false
        
        // Set a timeout to ensure we always send a response
        Handler(Looper.getMainLooper()).postDelayed({
            if (!locationSent) {
                locationSent = true
                Log.d(TAG, "Location request timed out")
                sendResponse(sender, "Could not get location (timeout)")
                stopSelf()
            }
        }, 30000) // 30 second timeout

        LocationUtils.getCurrentLocation(this) { location ->
            if (!locationSent) {
                locationSent = true
                if (location != null) {
                    val locationStr = LocationUtils.formatLocation(location)
                    val mapsLink = "https://maps.google.com/?q=${location.latitude},${location.longitude}"
                    Log.d(TAG, "Got location: $locationStr")
                    sendResponse(sender, "$locationStr\n$mapsLink")
                } else {
                    Log.d(TAG, "Failed to get location")
                    sendResponse(sender, "Could not get location")
                }
                stopSelf()
            }
        }
    }
    
    private fun handleContactCommand(sender: String, args: List<String>) {
        Log.d(TAG, "Handling getcontact command in service")
        if (args.isEmpty()) {
            Log.d(TAG, "No contact name provided")
            sendResponse(sender, "Please provide contact name")
            return
        }
        val query = args.joinToString(" ")
        Log.d(TAG, "Searching for contact: $query")
        val contacts = ContactUtils.searchContacts(this, query)
        when {
            contacts.isEmpty() -> {
                Log.d(TAG, "No contacts found")
                sendResponse(sender, "Contact not found: $query")
            }
            contacts.size == 1 -> {
                val (name, number) = contacts[0]
                Log.d(TAG, "Found single contact: $name")
                sendResponse(sender, "$name: $number")
            }
            else -> {
                Log.d(TAG, "Found multiple contacts: ${contacts.size}")
                val (name, number) = contacts[0]
                sendResponse(sender, "$name: $number (${contacts.size - 1} more matches)")
            }
        }
    }
    
    private fun handleAlarmCommand(sender: String, args: List<String>) {
        Log.d(TAG, "Handling alarm command in service")
        if (args.isEmpty()) {
            sendResponse(sender, "Please provide alarm duration in seconds")
            return
        }
        val duration = args[0].toIntOrNull()
        if (duration == null) {
            sendResponse(sender, "Invalid duration. Please provide a number in seconds")
            return
        }
        AlarmUtils.startAlarm(this, duration)
        sendResponse(sender, "Alarm started for $duration seconds")
    }

    private fun sendResponse(recipient: String, message: String) {
        try {
            Log.d(TAG, "Sending response to $recipient: $message")
            SmsManager.getDefault().sendTextMessage(
                recipient,
                null,
                message,
                null,
                null
            )
            Log.d(TAG, "Response sent successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to send response", e)
        }
    }

    private fun releaseWakeLock() {
        if (wakeLock?.isHeld == true) {
            wakeLock?.release()
            wakeLock = null
            Log.d(TAG, "Service wake lock released")
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                CHANNEL_ID,
                "FindIt Command Processing",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Used for processing SMS commands"
                setShowBadge(false)
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("FindIt Active")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_notification)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()
    }
} 