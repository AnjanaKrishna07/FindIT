package com.example.findit

import android.content.Context
import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.widget.Toast
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object SecurityUtils {
    private const val ANDROID_KEYSTORE = "AndroidKeyStore"
    private const val KEY_ALIAS = "FindItKey"
    internal const val PREFS_NAME = "FindItPrefs"
    private const val KEY_PASSCODE = "passcode"
    private const val KEY_WHITELIST = "whitelist"

    private fun getKeyStore(): KeyStore {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE)
        keyStore.load(null)
        return keyStore
    }

    private fun getOrCreateKey(): SecretKey {
        val keyStore = getKeyStore()
        if (!keyStore.containsAlias(KEY_ALIAS)) {
            val keyGenerator = KeyGenerator.getInstance(
                KeyProperties.KEY_ALGORITHM_AES,
                ANDROID_KEYSTORE
            )
            val keyGenParameterSpec = KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build()
            keyGenerator.init(keyGenParameterSpec)
            keyGenerator.generateKey()
        }
        return keyStore.getKey(KEY_ALIAS, null) as SecretKey
    }

    fun encrypt(context: Context, data: String): String {
        try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
            val iv = cipher.iv
            val encrypted = cipher.doFinal(data.toByteArray())
            return Base64.encodeToString(iv + encrypted, Base64.DEFAULT)
        } catch (e: Exception) {
            Toast.makeText(context, "Encryption failed: ${e.message}", Toast.LENGTH_SHORT).show()
            return data
        }
    }

    fun decrypt(context: Context, encryptedData: String): String {
        try {
            val decoded = Base64.decode(encryptedData, Base64.DEFAULT)
            val iv = decoded.copyOfRange(0, 12)
            val encrypted = decoded.copyOfRange(12, decoded.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            val spec = GCMParameterSpec(128, iv)
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), spec)
            return String(cipher.doFinal(encrypted))
        } catch (e: Exception) {
            Toast.makeText(context, "Decryption failed: ${e.message}", Toast.LENGTH_SHORT).show()
            return encryptedData
        }
    }

    fun savePasscode(context: Context, passcode: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_PASSCODE, encrypt(context, passcode)).apply()
    }

    fun getPasscode(context: Context): String? {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val encrypted = prefs.getString(KEY_PASSCODE, null)
        return encrypted?.let { decrypt(context, it) }
    }

    fun isValidPasscode(context: Context, passcode: String): Boolean {
        val savedPasscode = getPasscode(context)
        return savedPasscode == passcode
    }

    fun saveWhitelist(context: Context, numbers: Set<String>) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val encryptedNumbers = numbers.map { encrypt(context, it) }.toSet()
        prefs.edit().putStringSet(KEY_WHITELIST, encryptedNumbers).apply()
    }

    fun getWhitelist(context: Context): Set<String> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val encryptedNumbers = prefs.getStringSet(KEY_WHITELIST, emptySet()) ?: emptySet()
        return encryptedNumbers.map { decrypt(context, it) }.toSet()
    }

    fun isAuthorizedNumber(context: Context, number: String): Boolean {
        val whitelist = getWhitelist(context)
        return whitelist.contains(number)
    }
} 