package com.example.findit

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Telephony
import android.telephony.SmsManager
import android.util.Log
import android.widget.Toast

class SmsReceiver : BroadcastReceiver() {
    companion object {
        private const val PREFIX = "findit"
        private const val TAG = "FindItSMSReceiver"
        private const val WAKE_LOCK_TAG = "com.example.findit:SMS_WAKE_LOCK"
    }

    override fun onReceive(context: Context?, intent: Intent?) {
        Log.d(TAG, "SMS Receiver triggered")

        if (context == null || intent == null) {
            Log.e(TAG, "Context or Intent is null, cannot proceed.")
            return
        }

        // Acquire a wake lock to ensure the device stays awake long enough for service to start
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        val wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            WAKE_LOCK_TAG
        )
        wakeLock.acquire(60000) // 60 seconds max

        try {
            Log.d(TAG, "Action: ${intent.action}")

            if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) {
                Log.d(TAG, "Not an SMS_RECEIVED action, ignoring")
                return
            }

            val messages = try {
                Telephony.Sms.Intents.getMessagesFromIntent(intent)
            } catch (e: Exception) {
                Log.e(TAG, "Error extracting messages from intent", e)
                null
            }

            if (messages == null) {
                Log.e(TAG, "Messages array is null, cannot proceed.")
                return
            }

            Log.d(TAG, "Received ${messages.size} PDUs")

            for (message in messages) {
                if (message == null) {
                    Log.w(TAG, "Received a null message object in the array, skipping.")
                    continue
                }
                val sender = message.originatingAddress
                val body = message.messageBody

                if (sender == null || body == null) {
                    Log.w(TAG, "Sender ($sender) or Body ($body) is null, skipping message.")
                    continue
                }
                
                val processedBody = body.trim().lowercase()
                Log.d(TAG, "Processing message from: $sender | Body: $processedBody")

                // Check if sender is authorized
                try {
                    if (!SecurityUtils.isAuthorizedNumber(context, sender)) {
                        Log.d(TAG, "Unauthorized sender: $sender")
                        sendResponse(context, sender, "Unauthorized number")
                        continue
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error during authorization check for $sender", e)
                    sendResponse(context, sender, "Error checking authorization")
                    continue // Don't process if authorization check fails
                }

                // Parse command
                val parts = processedBody.split(" ")
                Log.d(TAG, "Command parts: $parts")
                
                if (parts.size < 3 || parts[0] != PREFIX) {
                    Log.d(TAG, "Invalid command format")
                    sendResponse(context, sender, "Invalid command format. Use: findit <password> <command> [args]")
                    continue
                }

                val password = parts[1]
                val command = parts[2]
                val args = parts.drop(3)
                
                Log.d(TAG, "Parsed command: $command with ${args.size} arguments")

                // Verify password
                if (!SecurityUtils.isValidPasscode(context, password)) {
                    Log.d(TAG, "Invalid password")
                    sendResponse(context, sender, "Invalid password")
                    continue
                }

                Log.d(TAG, "Processing command: $command")
                
                // Handle commands that require async or long-running operations using a Service
                when (command) {
                    "getlocation", "getcontact", "alarm" -> {
                        Log.d(TAG, "Starting service for $command command")
                        val serviceIntent = Intent(context, CommandProcessingService::class.java).apply {
                            putExtra("command", command)
                            putExtra("sender", sender)
                            putStringArrayListExtra("args", ArrayList(args))
                            putExtra("wakeLockId", WAKE_LOCK_TAG)
                        }
                        // Use startForegroundService for API 26+ and startService for older versions
                        try {
                            context.startForegroundService(serviceIntent)
                            Log.d(TAG, "Service started successfully")
                        } catch (e: Exception) {
                            Log.e(TAG, "Failed to start command service", e)
                            sendResponse(context, sender, "Error: Could not process command")
                        }
                        // Send initial response
                        val initialMessage = when (command) {
                            "getlocation" -> "Processing location request..."
                            "getcontact" -> "Searching contacts..."
                            "alarm" -> "Setting up alarm..."
                            else -> "Processing request..."
                        }
                        sendResponse(context, sender, initialMessage)
                    }
                    // Handle other commands that can be processed immediately
                    else -> {
                        handleCommand(context, sender, command, args)
                    }
                }
            }
        } finally {
            // Release the wake lock when we're done
            if (wakeLock.isHeld) {
                wakeLock.release()
                Log.d(TAG, "Wake lock released")
            }
        }
    }

    private fun handleCommand(context: Context, sender: String, command: String, args: List<String>) {
        when (command) {
            "sound" -> {
                if (args.isEmpty()) {
                    sendResponse(context, sender, "Please specify mode: silent, vibrate, or normal")
                    return
                }
                when (args[0]) {
                    "silent" -> SoundUtils.setSilentMode(context)
                    "vibrate" -> SoundUtils.setVibrateMode(context)
                    "normal" -> SoundUtils.setNormalMode(context)
                    else -> {
                        sendResponse(context, sender, "Invalid sound mode. Use: silent, vibrate, or normal")
                        return
                    }
                }
                sendResponse(context, sender, "Sound mode changed to: ${args[0]}")
            }
            "lock" -> {
                Log.d(TAG, "Handling lock command")
                DeviceUtils.lockPhone(context)
                sendResponse(context, sender, "Device locked")
            }
            "status" -> {
                Log.d(TAG, "Handling status command")
                val soundMode = SoundUtils.getCurrentMode(context)
                Log.d(TAG, "Current sound mode: $soundMode")
                sendResponse(context, sender, "Status: $soundMode")
            }
            else -> {
                Log.d(TAG, "Unknown command: $command")
                sendResponse(context, sender, "Unknown command: $command")
            }
        }
    }

    private fun sendResponse(context: Context, recipient: String, message: String) {
        try {
            Log.d(TAG, "Sending response to $recipient: $message")
            SmsManager.getDefault().sendTextMessage(
                recipient,
                null,
                message,
                null,
                null
            )
            Log.d(TAG, "Response sent successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to send response", e)
            Toast.makeText(context, "Failed to send response: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
} 