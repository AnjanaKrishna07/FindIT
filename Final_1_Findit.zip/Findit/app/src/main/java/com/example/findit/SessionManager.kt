package com.example.findit

import android.content.Context
import android.content.SharedPreferences
import android.util.Log

class SessionManager(context: Context) {
    private val sharedPreferences: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    private val editor: SharedPreferences.Editor = sharedPreferences.edit()

    companion object {
        private const val TAG = "SessionManager"
        private const val PREF_NAME = "FindItSession"
        private const val KEY_IS_LOGGED_IN = "isLoggedIn"
        private const val KEY_USER_ID = "userId"
        private const val KEY_USER_EMAIL = "userEmail"
        private const val KEY_USER_PHONE = "userPhone"
    }

    fun createLoginSession(userId: String, email: String?, phone: String?) {
        try {
            editor.apply {
                putBoolean(KEY_IS_LOGGED_IN, true)
                putString(KEY_USER_ID, userId)
                putString(KEY_USER_EMAIL, email)
                putString(KEY_USER_PHONE, phone)
                commit() // Use commit() instead of apply() to ensure immediate write
            }
            Log.d(TAG, "Login session created for user: $userId")
        } catch (e: Exception) {
            Log.e(TAG, "Error creating login session", e)
            clearSession()
        }
    }

    fun clearSession() {
        try {
            editor.apply {
                clear()
                commit() // Use commit() instead of apply() to ensure immediate write
            }
            Log.d(TAG, "Session cleared")
        } catch (e: Exception) {
            Log.e(TAG, "Error clearing session", e)
        }
    }

    fun isLoggedIn(): Boolean {
        try {
            val isLoggedIn = sharedPreferences.getBoolean(KEY_IS_LOGGED_IN, false)
            val userId = sharedPreferences.getString(KEY_USER_ID, null)
            
            // Verify we have both login flag and user ID
            val isValidSession = isLoggedIn && !userId.isNullOrEmpty()
            Log.d(TAG, "Session check - isLoggedIn: $isLoggedIn, hasUserId: ${!userId.isNullOrEmpty()}")
            
            if (!isValidSession && isLoggedIn) {
                // Invalid session state, clear it
                clearSession()
            }
            
            return isValidSession
        } catch (e: Exception) {
            Log.e(TAG, "Error checking login status", e)
            clearSession()
            return false
        }
    }

    fun getUserId(): String? {
        return try {
            sharedPreferences.getString(KEY_USER_ID, null)
        } catch (e: Exception) {
            Log.e(TAG, "Error getting user ID", e)
            null
        }
    }

    fun getUserEmail(): String? {
        return try {
            sharedPreferences.getString(KEY_USER_EMAIL, null)
        } catch (e: Exception) {
            Log.e(TAG, "Error getting user email", e)
            null
        }
    }

    fun getUserPhone(): String? {
        return try {
            sharedPreferences.getString(KEY_USER_PHONE, null)
        } catch (e: Exception) {
            Log.e(TAG, "Error getting user phone", e)
            null
        }
    }
} 