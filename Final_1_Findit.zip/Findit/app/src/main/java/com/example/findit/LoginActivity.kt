package com.example.findit

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.util.Patterns
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.example.findit.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    private lateinit var databaseHelper: DatabaseHelper
    private lateinit var sessionManager: SessionManager

    companion object {
        private const val TAG = "LoginActivity"
        private const val PERMISSION_REQUEST_CODE = 100
        private val REQUIRED_PERMISSIONS = arrayOf(
            android.Manifest.permission.READ_CONTACTS,
            android.Manifest.permission.ACCESS_FINE_LOCATION,
            android.Manifest.permission.ACCESS_COARSE_LOCATION,
            android.Manifest.permission.RECEIVE_SMS,
            android.Manifest.permission.SEND_SMS,
            android.Manifest.permission.READ_PHONE_STATE,
            android.Manifest.permission.MODIFY_AUDIO_SETTINGS
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        try {
            // Initialize session manager and database
            sessionManager = SessionManager(this)
            databaseHelper = DatabaseHelper(this)
            
            // Always clear session when LoginActivity starts
            sessionManager.clearSession()
            
            // Ensure we have a test user in the database
            databaseHelper.ensureTestUser()
            
            // Check if user is already logged in
            if (sessionManager.isLoggedIn()) {
                Log.d(TAG, "User is already logged in, redirecting to MainActivity")
                startMainActivity()
                return
            }

            binding = ActivityLoginBinding.inflate(layoutInflater)
            setContentView(binding.root)

            // Set up input validation
            binding.emailPhoneEditText.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    validateInput(s.toString())
                }
            })

            // Set up click listeners
            binding.loginButton.setOnClickListener {
                attemptLogin()
            }

            binding.signUpTextView.setOnClickListener {
                startActivity(Intent(this, SignUpActivity::class.java))
            }

            // Check and request permissions immediately
            checkAndRequestPermissions()
        } catch (e: Exception) {
            Log.e(TAG, "Error in onCreate", e)
            Toast.makeText(this, "Error initializing app. Please try again.", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun startMainActivity() {
        try {
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            startActivity(intent)
            finish()
        } catch (e: Exception) {
            Log.e(TAG, "Error starting MainActivity", e)
            Toast.makeText(this, "Error starting app. Please try again.", Toast.LENGTH_LONG).show()
        }
    }

    private fun validateInput(input: String) {
        binding.emailPhoneInputLayout.error = null
        if (input.isEmpty()) return

        if (input.contains("@")) {
            // Validate email
            if (!Patterns.EMAIL_ADDRESS.matcher(input).matches()) {
                binding.emailPhoneInputLayout.error = "Invalid email format"
            }
        } else {
            // Validate phone number
            if (!isValidPhoneNumber(input)) {
                binding.emailPhoneInputLayout.error = "Please enter a valid phone number"
            }
        }
    }

    private fun isValidPhoneNumber(phone: String): Boolean {
        return phone.matches(Regex("^\\d{6,}$"))
    }

    private fun attemptLogin() {
        try {
            val emailPhone = binding.emailPhoneEditText.text.toString().trim()
            val password = binding.passwordEditText.text.toString().trim()

            // Reset errors
            binding.emailPhoneInputLayout.error = null
            binding.passwordInputLayout.error = null

            // Validate inputs
            if (emailPhone.isEmpty()) {
                binding.emailPhoneInputLayout.error = "Email or phone number is required"
                return
            }

            if (!emailPhone.contains("@") && !isValidPhoneNumber(emailPhone)) {
                binding.emailPhoneInputLayout.error = "Please enter a valid phone number"
                return
            }

            if (password.isEmpty()) {
                binding.passwordInputLayout.error = "Password is required"
                return
            }

            // For testing purposes, log the attempt
            Log.d(TAG, "Attempting login with: $emailPhone")

            // Check credentials
            val user = databaseHelper.checkUser(emailPhone, password)
            if (user != null) {
                Log.d(TAG, "Login successful for user: ${user.id}")
                
                // Create login session
                sessionManager.createLoginSession(user.id, user.email, user.phone)
                
                // Verify session was created
                if (sessionManager.isLoggedIn()) {
                    Log.d(TAG, "Session created successfully")
                    Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show()
                    startMainActivity()
                } else {
                    Log.e(TAG, "Session creation failed")
                    Toast.makeText(this, "Error creating session. Please try again.", Toast.LENGTH_LONG).show()
                }
            } else {
                // For testing purposes, show available credentials
                binding.emailPhoneInputLayout.error = "Invalid credentials. Try test@example.com / password123"
                binding.passwordInputLayout.error = " "
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error during login attempt", e)
            Toast.makeText(this, "Error during login. Please try again.", Toast.LENGTH_LONG).show()
        }
    }

    private fun checkAndRequestPermissions() {
        val permissionsToRequest = REQUIRED_PERMISSIONS.filter { permission ->
            ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED
        }.toTypedArray()

        if (permissionsToRequest.isNotEmpty()) {
            if (permissionsToRequest.any { permission ->
                ActivityCompat.shouldShowRequestPermissionRationale(this, permission)
            }) {
                showPermissionRationale(permissionsToRequest)
            } else {
                requestPermissions(permissionsToRequest)
            }
        }
    }

    private fun showPermissionRationale(permissions: Array<String>) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Permissions Required")
            .setMessage("FindIt needs certain permissions to function properly. These include access to SMS, contacts, location, and device features.")
            .setPositiveButton("Grant") { _, _ ->
                requestPermissions(permissions)
            }
            .setNegativeButton("Deny") { _, _ ->
                Toast.makeText(this, "Some features may not work without permissions", Toast.LENGTH_LONG).show()
            }
            .show()
    }

    private fun requestPermissions(permissions: Array<String>) {
        ActivityCompat.requestPermissions(this, permissions, PERMISSION_REQUEST_CODE)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                Toast.makeText(this, "All permissions granted", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Some permissions were denied", Toast.LENGTH_LONG).show()
            }
        }
    }
} 