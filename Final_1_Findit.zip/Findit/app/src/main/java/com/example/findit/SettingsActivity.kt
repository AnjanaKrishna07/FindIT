package com.example.findit

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.findit.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySettingsBinding
    private lateinit var whitelistAdapter: WhitelistAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Settings"

        // Set up click listeners
        binding.notificationSwitch.setOnCheckedChangeListener { _, isChecked ->
            // Save notification preference
            getSharedPreferences("settings", MODE_PRIVATE).edit()
                .putBoolean("notifications_enabled", isChecked)
                .apply()
            Toast.makeText(this, 
                "Notifications ${if (isChecked) "enabled" else "disabled"}", 
                Toast.LENGTH_SHORT).show()
        }

        binding.securitySwitch.setOnCheckedChangeListener { _, isChecked ->
            // Save security preference
            getSharedPreferences("settings", MODE_PRIVATE).edit()
                .putBoolean("security_enabled", isChecked)
                .apply()
            Toast.makeText(this, 
                "Security features ${if (isChecked) "enabled" else "disabled"}", 
                Toast.LENGTH_SHORT).show()
        }

        // Load saved preferences
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        binding.notificationSwitch.isChecked = prefs.getBoolean("notifications_enabled", true)
        binding.securitySwitch.isChecked = prefs.getBoolean("security_enabled", true)

        binding.toolbar.setNavigationOnClickListener {
            finish()
        }

        // --- Passcode Management ---
        val savedPasscode = SecurityUtils.getPasscode(this)
        if (!savedPasscode.isNullOrEmpty()) {
            binding.passcodeEditText.setText(savedPasscode)
        }
        binding.savePasscodeButton.setOnClickListener {
            val passcode = binding.passcodeEditText.text?.toString()?.trim()
            if (passcode.isNullOrEmpty()) {
                Toast.makeText(this, "Passcode cannot be empty", Toast.LENGTH_SHORT).show()
            } else {
                SecurityUtils.savePasscode(this, passcode)
                Toast.makeText(this, "Passcode saved", Toast.LENGTH_SHORT).show()
            }
        }

        // --- Whitelist Management ---
        whitelistAdapter = WhitelistAdapter { numberToRemove ->
            val current = SecurityUtils.getWhitelist(this).toMutableSet()
            current.remove(numberToRemove)
            SecurityUtils.saveWhitelist(this, current)
            whitelistAdapter.updateWhitelist(current.toList())
            Toast.makeText(this, "Removed from whitelist", Toast.LENGTH_SHORT).show()
        }
        binding.whitelistRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.whitelistRecyclerView.adapter = whitelistAdapter
        whitelistAdapter.updateWhitelist(SecurityUtils.getWhitelist(this).toList())
        binding.addWhitelistButton.setOnClickListener {
            val number = binding.whitelistEditText.text?.toString()?.trim()
            if (number.isNullOrEmpty()) {
                Toast.makeText(this, "Phone number cannot be empty", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val current = SecurityUtils.getWhitelist(this).toMutableSet()
            if (current.contains(number)) {
                Toast.makeText(this, "Number already in whitelist", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            current.add(number)
            SecurityUtils.saveWhitelist(this, current)
            whitelistAdapter.updateWhitelist(current.toList())
            binding.whitelistEditText.setText("")
            Toast.makeText(this, "Added to whitelist", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
} 