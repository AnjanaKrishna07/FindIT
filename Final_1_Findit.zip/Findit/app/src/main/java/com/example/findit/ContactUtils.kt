package com.example.findit

import android.content.ContentResolver
import android.content.Context
import android.database.Cursor
import android.provider.ContactsContract
import android.widget.Toast

// ✅ Required standard Kotlin imports
import kotlin.Pair
import kotlin.collections.mutableListOf
import kotlin.let

object ContactUtils {

    // Helper extension to safely get a string by column name
    private fun Cursor.getStringByColumnName(columnName: String): String? {
        val index = getColumnIndex(columnName)
        return if (index >= 0) getString(index) else null
    }

    // ✅ Fetch contact number by name
    fun getContactNumber(context: Context, contactName: String): String? {
        val contentResolver: ContentResolver = context.contentResolver
        var cursor: Cursor? = null
        var phoneNumber: String? = null

        try {
            cursor = contentResolver.query(
                ContactsContract.Contacts.CONTENT_URI,
                null,
                "${ContactsContract.Contacts.DISPLAY_NAME} = ?",
                arrayOf(contactName),
                null
            )

            if (cursor?.moveToFirst() == true) {
                val contactId = cursor.getStringByColumnName(ContactsContract.Contacts._ID)

                contactId?.let { id ->
                    val phoneCursor = contentResolver.query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        null,
                        "${ContactsContract.CommonDataKinds.Phone.CONTACT_ID} = ?",
                        arrayOf(id),
                        null
                    )

                    if (phoneCursor?.moveToFirst() == true) {
                        phoneNumber = phoneCursor.getStringByColumnName(ContactsContract.CommonDataKinds.Phone.NUMBER)
                    }
                    phoneCursor?.close()
                }
            }
        } catch (e: Exception) {
            Toast.makeText(context, "Failed to get contact: ${e.message}", Toast.LENGTH_SHORT).show()
        } finally {
            cursor?.close()
        }

        return phoneNumber
    }

    // ✅ Get all contacts
    fun getAllContacts(context: Context): List<Pair<String, String>> {
        val contacts = mutableListOf<Pair<String, String>>()
        val contentResolver: ContentResolver = context.contentResolver
        var cursor: Cursor? = null

        try {
            cursor = contentResolver.query(
                ContactsContract.Contacts.CONTENT_URI,
                null,
                null,
                null,
                "${ContactsContract.Contacts.DISPLAY_NAME} ASC"
            )

            while (cursor?.moveToNext() == true) {
                val contactId = cursor.getStringByColumnName(ContactsContract.Contacts._ID)
                val name = cursor.getStringByColumnName(ContactsContract.Contacts.DISPLAY_NAME)

                if (contactId != null && name != null) {
                    val phoneCursor = contentResolver.query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        null,
                        "${ContactsContract.CommonDataKinds.Phone.CONTACT_ID} = ?",
                        arrayOf(contactId),
                        null
                    )

                    if (phoneCursor?.moveToFirst() == true) {
                        val phoneNumber = phoneCursor.getStringByColumnName(ContactsContract.CommonDataKinds.Phone.NUMBER)
                        if (phoneNumber != null) {
                            contacts.add(Pair(name, phoneNumber))
                        }
                    }
                    phoneCursor?.close()
                }
            }
        } catch (e: Exception) {
            Toast.makeText(context, "Failed to get contacts: ${e.message}", Toast.LENGTH_SHORT).show()
        } finally {
            cursor?.close()
        }

        return contacts
    }

    // ✅ Search contacts by partial name
    fun searchContacts(context: Context, query: String): List<Pair<String, String>> {
        val contacts = mutableListOf<Pair<String, String>>()
        val contentResolver: ContentResolver = context.contentResolver
        var cursor: Cursor? = null

        try {
            cursor = contentResolver.query(
                ContactsContract.Contacts.CONTENT_URI,
                null,
                "${ContactsContract.Contacts.DISPLAY_NAME} LIKE ?",
                arrayOf("%$query%"),
                "${ContactsContract.Contacts.DISPLAY_NAME} ASC"
            )

            while (cursor?.moveToNext() == true) {
                val contactId = cursor.getStringByColumnName(ContactsContract.Contacts._ID)
                val name = cursor.getStringByColumnName(ContactsContract.Contacts.DISPLAY_NAME)

                if (contactId != null && name != null) {
                    val phoneCursor = contentResolver.query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        null,
                        "${ContactsContract.CommonDataKinds.Phone.CONTACT_ID} = ?",
                        arrayOf(contactId),
                        null
                    )

                    if (phoneCursor?.moveToFirst() == true) {
                        val phoneNumber = phoneCursor.getStringByColumnName(ContactsContract.CommonDataKinds.Phone.NUMBER)
                        if (phoneNumber != null) {
                            contacts.add(Pair(name, phoneNumber))
                        }
                    }
                    phoneCursor?.close()
                }
            }
        } catch (e: Exception) {
            Toast.makeText(context, "Failed to search contacts: ${e.message}", Toast.LENGTH_SHORT).show()
        } finally {
            cursor?.close()
        }

        return contacts
    }
}
